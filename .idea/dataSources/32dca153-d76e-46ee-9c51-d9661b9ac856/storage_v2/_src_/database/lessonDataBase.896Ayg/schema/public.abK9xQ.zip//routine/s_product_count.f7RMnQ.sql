create function s_product_count(s_id character varying) returns integer
    language plpgsql
as
$$
declare  
 pcount int;
begin 
    select count(*) into pcount from sp where sid = s_id;
  return pcount;
end;
$$;

alter function s_product_count(varchar) owner to postgres;

