create function between_product(login_user character varying, password_user character varying) returns boolean
    language plpgsql
as
$$
declare
found boolean;
begin 
  select (password = password_user) into found from profile where login = login_user;
  return found;
end;
$$;

alter function between_product(varchar, varchar) owner to postgres;

