create function worker_history_trigg() returns trigger
    language plpgsql
as
$$
begin
	insert into worker_history(worker_id,detail_from, detail_to, action_type, changed_on)
		values(old.id, row_to_json(old), row_to_json(new), tg_OP, now());
		return new;
end;
$$;

alter function worker_history_trigg() owner to postgres;

