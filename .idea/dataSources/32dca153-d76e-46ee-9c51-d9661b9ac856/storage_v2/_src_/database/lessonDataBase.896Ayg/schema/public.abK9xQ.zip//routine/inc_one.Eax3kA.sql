create function inc_one(s_id character varying) returns integer
    language plpgsql
as
$$
declare
 pcount int;
begin
	 select count(*) into pcount from sp where s_id = sp.sid;
	 return pcount;
end;
$$;

alter function inc_one(varchar) owner to postgres;

