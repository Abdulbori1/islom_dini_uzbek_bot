create function worker_history_function() returns trigger
    language plpgsql
as
$$
BEGIN 
  if TG_OP = 'INSERT' then
    INSERT INTO worker_history(worker_id,detail_from,detail_to,action_type,changed_on) 
      VALUES(new.id,null,row_to_json(new),TG_OP,now()) ;
  elsif TG_OP = 'UPDATE' then  
     INSERT INTO worker_history(worker_id,detail_from,detail_to,action_type,changed_on) 
      VALUES(old.id,row_to_json(old),row_to_json(new),TG_OP,now()) ;
  elsif TG_OP = 'DELETE' then  
     INSERT INTO worker_history(worker_id,detail_from,detail_to,action_type,changed_on) 
      VALUES(old.id,row_to_json(old),TG_OP,now()) ;  
	  return old;
  end if;    
  return new;
END;
$$;

alter function worker_history_function() owner to postgres;

