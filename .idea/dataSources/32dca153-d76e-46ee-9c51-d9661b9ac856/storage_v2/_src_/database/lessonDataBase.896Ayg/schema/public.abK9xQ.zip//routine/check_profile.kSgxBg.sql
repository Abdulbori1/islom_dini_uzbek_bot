create function check_profile() returns character varying
    language plpgsql
as
$$
declare
p_id varchar;
begin
   select max(qty), pid into p_id  from sp group by pid;
   return pid;
end;
$$;

alter function check_profile() owner to postgres;

