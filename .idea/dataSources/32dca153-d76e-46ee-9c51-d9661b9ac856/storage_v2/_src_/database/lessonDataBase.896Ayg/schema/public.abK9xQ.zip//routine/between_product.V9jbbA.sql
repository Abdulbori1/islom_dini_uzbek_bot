create function between_product(a integer, b integer) returns integer
    language plpgsql
as
$$
declare
pcount int;
begin 
   select count(*) into pcount from p where size between a and b;
  return pcount;
end;
$$;

alter function between_product(integer, integer) owner to postgres;

